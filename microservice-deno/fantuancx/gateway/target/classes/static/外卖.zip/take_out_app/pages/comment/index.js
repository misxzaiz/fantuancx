import {request} from '../../request/index'
Page({
  data: {
    // orderList:[{id:0,createTime:"2022-01-01 00:01:00",orderNo:"202201010001",totalPrice:"38.00",status:"已完成",isComment:"1",dishsList:[{id:1,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"},{id:0,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"}]},{id:1,createTime:"2022-01-01 00:01:00",orderNo:"202201010001",totalPrice:"38.00",status:"已完成",isComment:"0",dishsList:[{id:1,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"},{id:0,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"}]}],  //订单的列表
    prevewImageList:[{url:"http://47.120.8.161/img/喜欢-红.png",id:0},{url:"http://47.120.8.161/img/聊天-红.png",id:0},{url:"http://47.120.8.161/img/喜欢-红.png",id:1},{url:"http://47.120.8.161/img/聊天-红.png",id:2}],
    orderList:[],//订单的列表
    showjubao:false,
    StarValue:4,
    commentList:[], //评论的列表
    isSatisfied:["很不满意","不满意","一般","满意","很满意"], //是否满意
  },
  onLoad(options) {

  },
  onShow() {
    this.getUncommentOrders()//获取未评价的订单列表
    this.getCommentList()  
  },    
  async getCommentList(){
    const userInfo=wx.getStorageSync('userInfo')
    const {id}=userInfo
    const res=await request({url:"comment/user/"+id})
    console.log(res);
    //将满意程度添加到commentList中
    res.data.data.forEach(v=>{
      v.isSatisfied=this.data.isSatisfied[Math.floor(v.averageScore)-1]
    })
    this.setData({
      commentList:res.data.data
    })
  },
  async getUncommentOrders(){
    const userInfo=wx.getStorageSync('userInfo')
    const {id}=userInfo
    const res=await request({url:"orders/isNotComment/"+id})
    // console.log(res);

    res.data.data.forEach(i=>{
      let sum=0
      i.dishsList.forEach(j=>{
        sum=sum+j.dishNum
      })
      //为每一个订单添加一个总件数
      i.piece=sum
    })

    this.setData({
      orderList:res.data.data
    })
  },
  //点击展示举报的上拉框
  onClosejubao(){
    this.setData({showjubao:false})
  },
  onCanceljubao(){
    this.setData({showjubao:false})
  },
  //点击省略号触发函数
  onClickPoints(e){
    // console.log(e);
    this.setData({showjubao:true})
  },
  //点击预览图片
  handlePrevewImage(e){
    // console.log(e);
    let {imgid,commentid}=e.currentTarget.dataset
    // console.log(imgid,commentid);
    // return
    let currentImgUrl="" //找到对应的图片url
    let urls=[] //找到对应的评论图片列表的url数组
    this.data.commentList.forEach(i=>{
      if(i.id==commentid){
        i.commentImages.forEach(j=>{
          if(j.id==imgid){
            currentImgUrl=j.imagePath
          }
        })
        urls=i.commentImages.map(v=>{
          return v.imagePath
        })
        return
      }
    })
    // console.log(currentImgUrl);
    // console.log(urls);
    wx.previewImage({
      current:currentImgUrl, // 当前显示图片的http链接
      urls, // 需要预览的图片http链接列表
      success:res=>{
        // console.log(res);
      },
      fail:res=>{
        // console.log(res);
      }
    })
  },
  //点击评价按钮触发函数
  goToEvaluate(e){
    const {orderid}=e.currentTarget.dataset
    // console.log(orderid);
    wx.navigateTo({
      url: '/pages/evaluate/index?orderid='+orderid,
    })
  },
  onPullDownRefresh() {

  },
  onReachBottom() {

  },
  onShareAppMessage() {

  }
})