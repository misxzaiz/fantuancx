import {request} from '../../request/index'
Page({
    data: {
      address:'',
      cartDishs:[], //购物车数据
      sumMoney:0, //总钱数
      allSelect:false 
    },
    onLoad(options) {
      
    },
    onShow(){
      this.initSumMoney_cartDishs()//获取购物车的数据列表
      this.computedallSelect()
      this.getAddressDate() //获取地址的数据
    },
    getAddressDate(){
      const address=wx.getStorageSync('address')
      this.setData({
        address
      })
    },
    //计算allSelect应该为true还是false
    computedallSelect(){
      //单选框有一个没有选，allSelect都应该设置为false
      let NoAllSelect= this.data.cartDishs.some(v=>{
        return v.checked==false
      })
      this.setData({
        allSelect:!NoAllSelect
      })
      //如果购物车没有菜了，直接取消全选
      if(this.data.cartDishs.length===0){
        this.setData({
          allSelect:false
        })
      }
    },
    AllradioChange(e){
      this.setData({
        allSelect:!this.data.allSelect
      })
      let {cartDishs,allSelect}=this.data
      if(allSelect){
        cartDishs.forEach(v=>{
          v.checked=true
        })
      }else{
        cartDishs.forEach(v=>{
          v.checked=false
        })
      }
      this.setData({
        cartDishs
      })
      wx.setStorageSync('cartDishs', cartDishs)
      this.computeSumMoney()
    },
    radioChange(e){
      const {dishid}=e.currentTarget.dataset
      let {cartDishs}=this.data
      // console.log(dishid);
      cartDishs.forEach(v=>{
        if(v.dishId==dishid){
          v.checked=!v.checked
        }
      })
      this.setData({
        cartDishs
      })
      wx.setStorageSync('cartDishs', cartDishs)
      //看所有单选框是否已经选上
      let allSelectIsSelect=this.data.cartDishs.every(v=>{
        return v.checked!=false
      })
      // console.log(allSelectIsSelect);
      if(allSelectIsSelect){
        this.setData({
          allSelect:true
        })
      }else{
        this.setData({
          allSelect:false
        })
      }
      wx.setStorageSync('cartDishs', cartDishs)
      this.computeSumMoney()//重新计算金额
    },
    handleItemNumEdit(e){
      // console.log(e);
      let {operation,id}=e.currentTarget.dataset //id是dishId
      let {cartDishs}=this.data
      cartDishs.forEach((v,index)=>{
        if(v.dishId==id){
          v.dishNum=v.dishNum+operation
        }
        if(v.dishNum==0){
          cartDishs.splice(index,1)
        }
      })
      this.computeSumMoney()
      this.setData({
        cartDishs
      })
      wx.setStorageSync('cartDishs', cartDishs)
    },
    //计算价格总金额
    computeSumMoney(){
      let sumMoney=0
      this.data.cartDishs.forEach(v=>{
        if(v.checked){
          sumMoney=sumMoney+v.dishNum*v.price
        }
      })
      this.setData({
        sumMoney
      })
    },
    initSumMoney_cartDishs(){
      let cartDishs=wx.getStorageSync('cartDishs')||[]
      //let sumMoney=0
      cartDishs.forEach(v=>{
        if(v.checked==undefined){
          v.checked=true //加上单选框选中
        }
        //sumMoney=sumMoney+v.dishNum*v.price
      })
      
      this.setData({
        //sumMoney,
        cartDishs
      })
      wx.setStorageSync('cartDishs', cartDishs)
      this.computeSumMoney()
    },
    //点击获取地址按钮触发函数
    handleChooseAddress(){
      // console.log("哈哈")
      //调用微信的api，获取收货地址
      wx.chooseAddress({
        success: (result) => {
          wx.setStorageSync('address', result) //存入缓存
          this.setData({
            address:result
          })
        }
      })
    },
    //点击提交订单按钮触发函数
    async onClickSubmit(){
      if(this.data.sumMoney==0){
        wx.showToast({
          title: '还没有选择商品噢！',
        })
        return
      }
      const address=wx.getStorageSync('address')
      if(!address){
        wx.showToast({
          title: '还没有选择地址噢！',
        })
        return
      }
      wx.setStorageSync('sumMoney', this.data.sumMoney) //调整到付款页面之前保存总金额到本地存储
      //发送请求，将订单改为未完成
      let orderId=await this.putOrders()
      // console.log(orderId);
      wx.navigateTo({
        url: '/pages/pay/index?orderId='+orderId,
      })
    },
    async putOrders(){
      let cartDishs=wx.getStorageSync('cartDishs')
      let checkCartList=cartDishs.filter(v=>{
        if(v.checked){
          return v
        }
      })
      const takeoutOrgoStore=wx.getStorageSync('takeoutOrgoStore')
      const userInfo=wx.getStorageSync('userInfo')
      const {id}=userInfo
      const addressinfo=wx.getStorageSync('address')
      let address=addressinfo.cityName+addressinfo.countyName+addressinfo.detailInfo
      const res=await request({url:"orders/",data:{checkCartList,takeoutOrgoStore,id,address},method:"POST"})
      // console.log(res);
      return res.data.data
    }
    ,
    onPullDownRefresh() {

    },
    onReachBottom() {

    }
})