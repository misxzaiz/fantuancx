import {uploadCommentPic,request} from '../../request/index'
Page({
  data: {

    evaluate:{
      storeScore:0, //存储商家评分
      flavorScore:0, //口味评分
      wrapScore:0,  //包装评分
      deliveryScore:0,   //配送评分
      textEvaluate:"" //评论的文本
    },
    isSatisfied:["很不满意","不满意","一般","满意","很满意"], //是否满意
    storeScoreSatisfied:"", //商家评分满意度
    flavorScoreSatisfied:"" ,//口味评分满意度
    wrapScoreSatisfied:"" ,//包装评分满意度
    deliveryScoreSatisfied:"" ,//配送评分满意度
    file:[],//存储文件上传时的信息
    fileList:[]//预览的文件信息
  },
  onLoad(options) {

  },
  onShow() {

  },
  //点击发布触发函数
  async publishComment(){
    const userInfo=wx.getStorageSync('userInfo')
    const {id}=userInfo
    //获取订单id
    const pages=getCurrentPages()
    const currentPage=pages[pages.length-1]
    const orderid=currentPage.options.orderid
    // console.log(orderid);
    let {evaluate}=this.data
    evaluate.orderId=orderid
    evaluate.userId=id
    //发送评论文本和评分数据给后端 
    const res1=await request({url:"comment/",data:evaluate,method:"POST"})
    console.log(res1);
    if(res1.data.code!=200) return  //不成功直接返回
    const commentId=res1.data.data
    //发送图片列表给后端
    const {file}=this.data
    let promises=[]
    file.forEach(v=>{
      const res= uploadCommentPic({url:'comment/upload',file:v,commentId})
      promises.push(res)
    })
    Promise.all(promises).then(res=>{
      console.log(res);
      const allRight= res.every(v=>{
        return v.statusCode==200
      })
      // console.log(allRight);
      if(allRight){
        wx.showToast({
          title: '评论成功！',
          mask:true
        })
      }
     setTimeout(res=>{
      wx.navigateBack()
     },800)
    })
        // const res=await uploadCommentPic({url:'comment/upload',phone,username,file:this.data.file,id})
  },
  deleteChooseImg(e){
    // console.log(e);
    let {fileList}=this.data
    const index=e.detail.index
    console.log(index);
    fileList.splice(index,1)
    this.setData({
      fileList
    })
  },
  async afterRead(event) {
    // console.log(event.detail);
    // return
    const { file } = event.detail;
    let fileList=[]
    fileList.push({url:event.detail.file.url,deletable: true})
    this.setData({
      file:[...this.data.file,file],
      fileList:[...this.data.fileList,...fileList]})
  },
  //输入文本框时触发函数
  inputChange(event){
    // console.log(event.detail.value);
    this.setData({
      'evaluate.textEvaluate':event.detail.value
    })
  },
  //更改商家评分时触发函数
  onChangeScore(event) {
    this.setData({
      'evaluate.storeScore': event.detail,
      storeScoreSatisfied:this.data.isSatisfied[Math.floor(event.detail)-1]
    });
    // console.log(Math.floor(event.detail));
  },
    onChangeFlavorScore(event) {
      this.setData({
        'evaluate.flavorScore': event.detail,
        flavorScoreSatisfied:this.data.isSatisfied[Math.floor(event.detail)-1]
      });
    },
    //更改包装评分时触发函数
    onChangeWarpScore(event) {
    this.setData({
      'evaluate.wrapScore': event.detail,
      wrapScoreSatisfied:this.data.isSatisfied[Math.floor(event.detail)-1]
    });
  },
    onChangeDeliveryScore(event) {
      this.setData({
        'evaluate.deliveryScore': event.detail,
        deliveryScoreSatisfied:this.data.isSatisfied[Math.floor(event.detail)-1]
      });
    },
  onPullDownRefresh() {

  },
  onReachBottom() {

  }
})