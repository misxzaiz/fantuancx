import {request} from '../../request/index'
Page({
  data: {
    address:{},
    checkCartList:[],
    sumMoney:0 
  },
  onLoad(options) {
    const address=wx.getStorageSync('address')
    this.setData({
      address
    })
  },
  onShow() {
    this.getCheckCartListDate()
    this.getSumMoneyData()
  },
  //点击支付
   onClickPay(){
    wx.showModal({
      content: '你真的要付款吗？付款你会倾家荡产噢！',
      title: '提示',
      success:async (result) => {
        // console.log(result);
        if(result.confirm==true){
          //发送请求，后台添加订单
          // const takeoutOrgoStore=wx.getStorageSync('takeoutOrgoStore')
          // const userInfo=wx.getStorageSync('userInfo')
          // const {id}=userInfo
          // const addressinfo=wx.getStorageSync('address')
          // let address=addressinfo.cityName+addressinfo.countyName+addressinfo.detailInfo
          // const res=await request({url:"orders/",data:{checkCartList:this.data.checkCartList,takeoutOrgoStore,id,address},method:"POST"})
          // console.log(res);
          // return
          let pages=getCurrentPages()
          let currentPage=pages[pages.length-1]
          const {orderId}=currentPage.options
          // console.log(orderId);
          // return
          const res=await request({url:"orders/updateOrderStatus/"+orderId})
          console.log(orderId);
          if(res.data.code!=200) {
            wx.showToast({
              title: '支付失败',
              mask:true,
              icon:'error'
            })
            return
          }
          let cartDishs=wx.getStorageSync('cartDishs')
          cartDishs=cartDishs.filter(v=>{
            return v.checked===false
          })
          wx.setStorageSync('cartDishs', cartDishs)
          wx.setStorageSync('sumMoney', 0)
          this.setData({
            checkCartList:[],
            sumMoney:0
          })
          wx.showToast({
            title: '付款成功',
            icon:'success'
          })
          setTimeout(()=>{
            wx.navigateBack()
          },800)
        }
      },
      fail: (res) => {},
      complete: (res) => {},
    })
  },
  getSumMoneyData(){
    let sumMoney=wx.getStorageSync('sumMoney')
    this.setData({
      sumMoney
    })
  },
  getCheckCartListDate(){
    let cartDishs=wx.getStorageSync('cartDishs')
    let checkCartList=cartDishs.filter(v=>{
      if(v.checked){
        return v
      }
    })
    this.setData({
      checkCartList
    })
  },
  onPullDownRefresh() {

  },
  onReachBottom() {

  }
})