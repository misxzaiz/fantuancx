// pages/user/index.js
Page({
  data: {
    userInfo:{
      collectNums:0 //被收藏的商品数量
    }
  },
  //点击重新登录触发函数
  handleLoginAgain(){
    wx.navigateTo({
      url: '/pages/login/index',
    })
  },
  //点击编辑用户信息
  editUserInfo(){
    wx.navigateTo({
      url: '/pages/edit_user_info/index',
    })
  },
  onShow(){
    const userInfo=wx.getStorageSync('userInfo')||null
    const collect=wx.getStorageSync('collect')||[]
    this.setData({
      userInfo,
      collectNums:collect.length
    })
    // 获取用户信息
   this.userInfo() //每次打开用户页面都获取一次用户信息
  },
  //点击头像预览
  priveiwPic(){
    const {avatarPath}=this.data.userInfo
    wx.previewImage({
      current: avatarPath, // 当前显示图片的http链接
      urls: [avatarPath] // 需要预览的图片http链接列表
    })
  },
  userInfo(){
    const userInfo=wx.getStorageSync('userInfo')
    this.setData({
      userInfo
    })
  },
  handleComment(){
    wx.navigateTo({
      url: '/pages/comment/index',
    })
  },
  //点击关于我们触发函数
  handleaboutus(){
    wx.navigateTo({
      url: '/pages/aboutus/index',
    })
  }
})