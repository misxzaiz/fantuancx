Page({
  data: {
    swiperList:[{
      url:"/images/bbq-home1.jpg",
      id:0
    },
    {
      url:"/images/bbq-home2.jpg",
      id:1
    },{
      url:"/images/bbq-home3.jpg",
      id:2
    },{
      url:"/images/bbq-home4.jpg",
      id:3
    }],//轮播图数据
    takeOrShop:[{url:"/images/takeout.jpg",id:0,info:"外卖到家"},{url:"/images/shop.jpg",id:1,info:"到店自取"}],//外卖或者到店吃
    storeList:[{id:0,url:"http://47.120.8.161/img/店面1.jpg"},{id:1,url:"http://47.120.8.161/img/店面2.jpg"},{id:2,url:"http://47.120.8.161/img/店面3.jpg"},{id:3,url:"http://47.120.8.161/img/店面4.jpg"}]//门店图片
  },
  onLoad(options) {

  },
  onShow() {

  },
  //点击预览图片
  handlePrevewImage(e){
    let {id}=e.currentTarget.dataset
    let currentImgUrl="" //找到对应的图片url
    this.data.storeList.forEach((v,index)=>{
      if(v.id==id){
        currentImgUrl=v.url
        return
      }
    })
    //构造要预览的图片数组
    const urls=this.data.storeList.map((v)=>{
      return v.url
    })
    wx.previewImage({
      current:currentImgUrl, // 当前显示图片的http链接
      urls, // 需要预览的图片http链接列表
      success:res=>{
        // console.log(res);
      },
      fail:res=>{
        // console.log(res);
      }
    })
  },
  //带着type（外卖0/到店自取1）跳到
  goToMeun(e){
    const type=e.currentTarget.dataset.id
    // console.log(type);
    wx.reLaunch({
      url: '/pages/menu/index?type='+type,
    })
  },
  onPullDownRefresh() {

  },
  onReachBottom() {

  }
})