import {request} from '../../request/index'
Page({

  data: {
    isChecked:false,
    userInfo:{}
  },
  onLoad(options) {

  },
  onShow() {

  },
  //点击登录时触发表单提交事件
  async onSubmit(e){
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    const {password,phone}=e.detail.value
    if(e.phone !== ""){
      wx.showToast({
        title: '手机号未输入',
        mask:true
      })
    }
    if(e.password !== ""){
      wx.showToast({
        title: '密码未输入',
        mask:true
      })
    }
    if(this.data.isChecked==false){
      wx.showToast({
        title: '请勾选使用协议',
        mask:true
      })
      return
    }
    //发请求
    const res=await request({url:"users/login",method:"POST",data:{password:password.trim(),phone:phone.trim()}})
    console.log(res);
    if(res.data.code==400){
      wx.showToast({
        title: res.data.message,
        icon:'none'
      })
      return
    }
    this.setData({
      userInfo:res.data.data
    })
    wx.setStorageSync('userInfo', res.data.data)
    wx.showToast({
      title: res.data.message,
    })
    setTimeout(()=>{
      wx.switchTab({
        url: '/pages/user/index',
      })
    },800)
  },
  //点击复选框变为true
  isCheckedtrue(){
    this.setData({
      isChecked:true
    })
  },
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})