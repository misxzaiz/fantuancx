let ajaxTimes=0 
export const request=(params)=>{
  ajaxTimes++
  wx.showLoading({
    title: '加载中',
    mask:true
  })
  const baseUrl="http://10.60.113.69:10010/"
  return new Promise((resolve,reject)=>{
    wx.request({
      ...params, 
      url:baseUrl+params.url,  
      success:(result)=>{
        resolve(result) 
      },
      fail:(err)=>{
        reject(err)
      },
      complete:()=>{
        ajaxTimes--
        if(ajaxTimes==0){
          wx.hideLoading()
        }
      }
    })
  })
}
export const uploadFile=(params)=>{

    const baseUrl="http://10.60.113.69:10010/"
    return   new Promise((resolve,reject)=>{
      wx.uploadFile({

        url:baseUrl+params.url,  
        filePath: params.file.url,
        name: 'file',
        formData: { "username":params.username,"phone":params.phone ,"id":params.id },
        success(res) {
          resolve(res)

        },      
        fail:(err)=>{
          reject(err)
        },
      });
    })
}

export const uploadCommentPic=(params)=>{
  const baseUrl="http://10.60.113.69:10010/"
  return   new Promise((resolve,reject)=>{
    wx.uploadFile({
      url:baseUrl+params.url,  
      name: 'file',
      formData: { "commentId":params.commentId },
      success(res) {
        resolve(res)
      },      
      fail:(err)=>{
        reject(err)
      },
    });
  })
}