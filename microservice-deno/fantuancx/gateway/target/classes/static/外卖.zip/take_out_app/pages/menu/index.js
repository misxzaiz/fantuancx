import {request} from '../../request/index'
Page({
  data: {
    activeKey: 0,
    // navName:[{navId:0,navName:"网红小串"},{navId:1,navName:"蔬菜品类"},{navId:2,navName:"猪牛羊类"},{navId:3,navName:"鸡肉串类"},{navId:4,navName:"豆制品类"},{navId:5,navName:"生蚝海鲜"},{navId:6,navName:"炒粉田螺"},{navId:7,navName:"啤酒饮料"}],//左侧导航栏
    navName:[],
    // goods:{navId:0,navName:"网红小串",children:[{dishId:0,dishName:"碳烤深海鱿鱼小串",dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",price:"15",sales:"100",praise:"98%",dishNum:0},{dishId:1,dishName:"碳烤鸭肠小串",dishImg:"http://47.120.8.161/img/碳烤鸭肠小串.jpg",price:"16",sales:"100",praise:"98%",dishNum:0},{dishId:2,dishName:"碳烤玉米小串",dishImg:"http://47.120.8.161/img/碳烤玉米小串.jpg",price:"14",sales:"100",praise:"98%",dishNum:0}]},
    goods:[],
    //dishNum:0  //选择菜的数量
    show: false, //展示购物车的上拉框
    showjubao:false,//展示举报的上拉框
    cartDishs:[], 
    sumMoney:0, //存储总金额
    radio:"0",  
    StarValue:4.8,//商家评分
    tabs:[
      {
        id:0,
        value:"外卖评价",
        isActive:true
      },
      {
        id:1,
        value:"到店评价",
        isActive:false
      }
    ],
    // prevewImageList:[{url:"http://47.120.8.161/img/喜欢-红.png",id:0},{url:"http://47.120.8.161/img/聊天-红.png",id:0},{url:"http://47.120.8.161/img/喜欢-红.png",id:1},{url:"http://47.120.8.161/img/聊天-红.png",id:2}],//预览评论图片
    commentList:[], //评论的列表
    isSatisfied:["很不满意","不满意","一般","满意","很满意"], //是否满意
  },
  onLoad(options) {
    
    // console.log(options);
    const {type}=options||this.data.radio
    if(type==="1"){//到店自取,否则默认radio为0
      this.setData({
        radio:"1"
      })
    }
    //存入本地存储,默认为0
    const takeoutOrgoStore=wx.setStorageSync('takeoutOrgoStore', this.data.radio)
  },
  onShow(){
    const takeoutOrgoStore=wx.getStorageSync('takeoutOrgoStore')
    this.computedSumMoney()
    this.getNavNames()
    this.getCommentList(takeoutOrgoStore)  //获取已评价的评价列表(0是外卖评价，1是到店评价)
  },
  async getCommentList(takeoutOrgoStore=0){
    const res=await request({url:"comment/0/"+takeoutOrgoStore})
    console.log(res);
    //将满意程度添加到commentList中
    res.data.data.forEach(v=>{
      v.isSatisfied=this.data.isSatisfied[Math.floor(v.averageScore)-1]
    })
    this.setData({
      commentList:res.data.data
    })
  },
  //点击预览图片
  handlePrevewImage(e){
    // console.log(e);
    let {imgid,commentid}=e.currentTarget.dataset
    // console.log(imgid,commentid);
    // return
    let currentImgUrl="" //找到对应的图片url
    let urls=[] //找到对应的评论图片列表的url数组
    this.data.commentList.forEach(i=>{
      if(i.id==commentid){
        i.commentImages.forEach(j=>{
          if(j.id==imgid){
            currentImgUrl=j.imagePath
          }
        })
        urls=i.commentImages.map(v=>{
          return v.imagePath
        })
        return
      }
    })
    // console.log(currentImgUrl);
    // console.log(urls);
    wx.previewImage({
      current:currentImgUrl, // 当前显示图片的http链接
      urls, // 需要预览的图片http链接列表
      success:res=>{
        // console.log(res);
      },
      fail:res=>{
        // console.log(res);
      }
    })
  },
  //点击省略号触发函数
  onClickPoints(e){
    console.log(e);
    this.setData({showjubao:true})
  },
  //点击展示举报的上拉框
  onClosejubao(){
    this.setData({showjubao:false})
  },
  //点击关闭举报的下拉框
  onCanceljubao(){
    this.setData({showjubao:false})
  },
  //标题的子组件  从子组件传递过来
  handleTabsItemChange(e){
    // console.log(e)
    // 1、获取被点击的标题索引
    const{index}=e.detail
    console.log(index);
    wx.setStorageSync('takeoutOrgoStore', index)
    //每切换一次，就发送一次请求
    this.getCommentList(index)
    //2、修改源数组
    let {tabs}=this.data
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false)
    this.setData({
      tabs
    })
  },
  //获取左侧导航栏数据
  async getNavNames(){
    const res=await request({url:'dishCategory'})
    // console.log(res);
    this.setData({
      navName:res.data.data
    })
    this.getGoodsData()
  },
  // 获取右侧菜品列表数据
  async getGoodsData(id=1){
    const res=await request({url:'dishes/'+id})
    // console.log(res);
    
    this.setData({
      'goods.children':res.data.data
    })
    //获取数据完成后再对数据进行复原
    this.recoverData()
  },
  //点击清除购物车
  ClearCarts(){
    //将chilren所有的对象的dishNum清零
    let goodsChildren=this.data.goods.children
    goodsChildren.forEach(v=>{
      v.dishNum=0
    })
    this.setData({
      cartDishs:[],
      sumMoney:0,
      'goods.children':goodsChildren
    })
    wx.clearStorageSync('cartDishs')
  },
  //单选框改变触发函数
  onRadioChange(event) {
    this.setData({
      radio: event.detail,
    });
    //改变了配送方式，要修改存入本地存储
    wx.setStorageSync('takeoutOrgoStore', this.data.radio)
  },
  //关闭购物车信息时触发函数
  onClose(){
    this.setData({show:false})
  },
  //取消按钮点击时触发
  onCancel(){
    this.setData({show:false})
  },
  onOpenVanActionSheet(){
    let cartDishs=wx.getStorageSync('cartDishs')
    this.setData({
      cartDishs
    })
    this.setData({ show: true });
  },
  //点击左侧导航栏触发函数
  navChange(e){
    // console.log(e);
    this.setData({
      activeKey:e.detail
    })
    // console.log(this.data.activeKey);
    //发送请求
    // this.getGoodsData(this.data.activeKey+1)
    // this.setData({
    //   goods:res
    // })
  },
  //点击SidebarItem触发事件
  navClick(e){
    // console.log(e);
    let {id}=e.currentTarget.dataset
    // 发送请求
    this.getGoodsData(id)
  },
  //点击加号或者减号触发函数
  handleItemNumEdit(e){
    // console.log(e);
    let {operation,id}=e.currentTarget.dataset
    let childrensArray=this.data.goods.children//拷贝一份children数组，为了在后面操作num+operation
    //let index=this.data.goods.children.findIndex((v)=>v.dishId===id)
    // console.log(index);
    //点击加号后，要将所选择的菜品放到本地存储中
    let cartDishs=wx.getStorageSync('cartDishs')||[] //菜品数组存放选择的菜
    childrensArray.forEach(v=>{
      if(id===v.dishId){
        v.dishNum=v.dishNum+operation
        if(cartDishs.length==0){ //没有选择的菜品内容则直接插入数组前面
          cartDishs.unshift(v)
        }else{ 
          //有则遍历是否有有一样的菜品，一样则把原来的那个删除，再加上后面得到的新的菜品，因为dishNum会跟着变化
          let index1=cartDishs.findIndex(v=>{
            return v.dishId==id
          })
          console.log(index1);
          if(index1>=0){
            cartDishs.splice(index1,1)//删除当前的对象
            cartDishs.unshift(v)//重新添加回此对象
          }else{
            cartDishs.unshift(v)
          }
        }
      }
    })
    let index1=cartDishs.findIndex(v=>{ //在底部购物车中加减商品时会出现有0的的情况，将购买数量为0的商品从购物车数组中去除
      return v.dishNum==0
    })
    // console.log(index1);
    if(index1>=0){
      cartDishs.splice(index1,1)
    }

    this.setData({
      'goods.children':childrensArray,
      cartDishs
    })
    wx.setStorageSync('cartDishs', cartDishs)

    //点击加减号时动态更新总金额 
    this.computedSumMoney()
    
  },
  computedSumMoney(){
    let cartDishs=wx.getStorageSync('cartDishs')||[]
    let sumMoney=0
    cartDishs.forEach(v=>{
      sumMoney=sumMoney+v.dishNum*v.price
    })
    this.setData({
      sumMoney
    })
  },
  //重新打开页面恢复购物车在展示页面的数据
  recoverData(){
    let cartDishs=wx.getStorageSync('cartDishs')||[]
    let goodsChildren=this.data.goods.children
    goodsChildren.forEach(v=>{
      cartDishs.forEach(k=>{
        if(k.dishId===v.dishId){
          // console.log(v.dishId);
          v.dishNum=k.dishNum
        }
      })
    })
    this.setData({
      'goods.children':goodsChildren
    })
  },
  onPullDownRefresh() {

  },
  onReachBottom() {

  }
})