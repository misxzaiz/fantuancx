import {uploadFile} from '../../request/index'
Page({
  data: {
    username:'', //存储username
    file:null,
    fileList:[],
  },
  onLoad(options) {

  },
  onShow() {

  },
  //输入改变时触发函数
  inputChange(e){
    // console.log(e.detail);
    const {value}=e.detail
    this.setData({
      username:value
    })
  },
  //点击删除选中的图片触发函数
  deleteChooseImg(e){
    // console.log(e);
    this.setData({
      fileList:[]
    })
  },
  async afterRead(event) {
    console.log(event.detail);
    // return
    const { file } = event.detail;
    let fileList={url:event.detail.file.url,deletable: true} //将上传的头像保存到fileList,只保存一张图片
    this.setData({file,fileList:[fileList]})

  },
  //点击编辑提交确定按钮触发函数
  async editSubmit(){
    if(this.data.file==null){
      wx.showToast({
        title: '您的头像未上传',
      })
      return
    }
    let userInfo=wx.getStorageSync('userInfo')
    const {phone,id}=userInfo
    // const {id}=userInfo
    const {username}=this.data
    const res=await uploadFile({url:'users/update',phone,username,file:this.data.file,id})
    console.log(res);
    // console.log(JSON.parse(res.data));
    // return
    let userinfo=JSON.parse(res.data).data  //不设置为userInfo，因为上面已经定义了变量
    wx.setStorageSync('userInfo', userinfo)
    
    wx.showToast({
      title: '修改信息成功',
    })
    setTimeout(()=>{
      wx.reLaunch({
        url: '/pages/user/index',
      })
    },800)
    //获取公共ip
    // var ip=getApp().globalData.ip

  },
  onPullDownRefresh() {

  },
  onReachBottom() {

  },
  onShareAppMessage() {

  }
})