import Dialog from '@vant/weapp/dialog/dialog';
import {request} from '../../request/index'
Page({
  data: {
    activeNav:0,//激活的导航栏
    titleList:["全部订单","待付款","已收货","退货/退款"],//订单的title的列表
    // orderList:[{id:0,createTime:"2022-01-01 00:01:00",orderNo:"202201010001",totalPrice:"38.00",status:"已完成",isComment:"1",dishsList:[{id:1,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"},{id:0,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"}]},{id:1,createTime:"2022-01-01 00:01:00",orderNo:"202201010001",totalPrice:"38.00",status:"已完成",isComment:"0",dishsList:[{id:1,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"},{id:0,dishImg:"http://47.120.8.161/img/碳烤深海鱿鱼小串.jpg",dishName:"碳烤深海鱿鱼小串"}]}],  //订单的列表
    orderList:[],//订单的列表
    dialogShow:false,//删除的弹框是否显示
  },
  onLoad(options) {
    console.log(options);
    const {type}=options
    this.setData({
      activeNav:+type  //加个+变为数字才可以
    })
  },
  onShow() {
    this.getOrdersListByType() //获取订单数据
  },
  //点击支付触发函数
  async payOrder(e){
    // console.log(e);
    const {orderid}=e.currentTarget.dataset
    wx.showModal({
      content: '你真的要付款吗？付款你会倾家荡产噢！',
      title: '提示',
      success:async (result) => {
        // console.log(result);
        if(result.confirm==true){
          const res=await request({url:"orders/updateOrderStatus/"+orderid})
          console.log(res);
          if(res.data.code==200){
            wx.showToast({
              title: '支付成功',
              mask:true
            })
          }
          //付款之后再次请求就行
          this.getOrdersListByIndex(this.data.activeNav)
        }}
      })

  },
  //获取订单数据通过上个页面传过来的type
  async getOrdersListByType(){
    const pages=getCurrentPages()
    let CurrentPage=pages[pages.length-1]
    // console.log(pages[pages.length-1])
    const {type}=CurrentPage.options
    const userInfo=wx.getStorageSync('userInfo')
    const userId=userInfo.id
    let res=await request({url:"orders/"+userId+"/"+type})
    // console.log(res);
    
    res.data.data.forEach(i=>{
      let sum=0
      i.dishsList.forEach(j=>{
        sum=sum+j.dishNum
      })
      //为每一个订单添加一个总件数
      i.piece=sum
    })
    
    this.setData({
      orderList:res.data.data
    })

  },
  async getOrdersListByIndex(index){
    const userInfo=wx.getStorageSync('userInfo')
    const userId=userInfo.id
    const res=await request({url:"orders/"+userId+"/"+index})
    // console.log(res);
    res.data.data.forEach(i=>{
      let sum=0
      i.dishsList.forEach(j=>{
        sum=sum+j.dishNum
      })
      //为每一个订单添加一个总件数
      i.piece=sum
    })
    this.setData({
      orderList:res.data.data
    })
  },
  //Dialog弹框关闭时触发
  onDialogClose(){
    this.setData({dialogShow:false})
  },
  deleteOrder(e){
    // console.log(e);
    // return
    //根据id删除
    const {id}=e.currentTarget.dataset
    // this.setData({
    //   dialogShow:true
    // })
    Dialog.confirm({
      title: '确认删除吗？',
      
    }).then(async (res) => {
        // on confirm
        // console.log("确认",res);
        // 根据id发起删除订单请求
        const res1=await request({url:"orders/deleteOrder/"+id,method:"DELETE"})
        console.log(res1);
        if(res1.data.code==200){
          wx.showToast({
            title: res1.data.message,
          })
          setTimeout(res=>{
            this.getOrdersListByIndex(this.data.activeNav)
          },800)
        }

      }).catch((res) => {
        // on cancel
        console.log("取消",res);
      });
    
  },
  navChange(e){
    // console.log(e);
    const {index}=e.detail
    this.getOrdersListByIndex(index)
    this.setData({
      activeNav:index
    })
  },
  onReachBottom() {

  },
  onShareAppMessage() {

  }
})